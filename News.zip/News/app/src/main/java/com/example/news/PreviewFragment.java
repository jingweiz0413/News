package com.example.news;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.widget.Button;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class PreviewFragment extends Fragment implements View.OnClickListener {

    private Activity containerActivity;
    private String url;
    public void setContainerActivity(Activity containerActivity) {
        this.containerActivity = containerActivity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_preview, container, false);
        Button b = (Button) v.findViewById(R.id.readOn);
        b.setOnClickListener(this);
        String title = getArguments().getString("title");
        String des = getArguments().getString("description");
        url = getArguments().getString("url");
        TextView t1 = v.findViewById(R.id.title);
        t1.setText(title);
        t1 = v.findViewById(R.id.des);
        t1.setText(des);
        return v;
    }

    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        bundle.putString("url",url);
        WebFragment f3 = new WebFragment();
        FragmentManager fm = getFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();
        f3.setArguments(bundle);
        transaction.replace(((ViewGroup)getView().getParent()).getId(), f3);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
