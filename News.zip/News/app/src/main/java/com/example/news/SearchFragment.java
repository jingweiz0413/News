package com.example.news;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.AdapterView;
import java.util.ArrayList;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import java.util.Date;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.text.SimpleDateFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import android.widget.Button;

public class SearchFragment extends Fragment implements View.OnClickListener {
    private Activity containerActivity;
    private JSONArray array;
    private View v;
    private boolean opened;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_search, container, false);
        Button b = (Button) v.findViewById(R.id.searchButton);
        b.setOnClickListener(this);
        ListView l = (ListView) v.findViewById(R.id.listView);
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                JSONObject json = new JSONObject();
                try {
                    json = array.getJSONObject(position);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Bundle bundle = new Bundle();
                try {
                    bundle.putString("title",json.getString("title"));
                    bundle.putString("description",json.getString("description"));
                    bundle.putString("url",json.getString("url"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                PreviewFragment f2 = new PreviewFragment();
                FragmentManager fm = getFragmentManager();
                FragmentTransaction transaction = fm.beginTransaction();
                f2.setArguments(bundle);
                transaction.replace(((ViewGroup)getView().getParent()).getId(), f2,"frag2");
                transaction.addToBackStack(null);
                transaction.commit();
            }
        });


        return v;
    }


    public void setContainerActivity(Activity containerActivity) {
        this.containerActivity = containerActivity;
    }

    @Override
    public void onClick(View view){
        EditText et = containerActivity.findViewById(R.id.edit);
        if(!et.getText().toString().equals("")) {
            opened = true;
            AT at = new AT();
            at.execute();
        }

    }

    @Override
    public void onResume(){
        super.onResume();
        EditText et = containerActivity.findViewById(R.id.edit);
        if(!et.getText().toString().equals("")) {
            opened = true;
            AT at = new AT();
            at.execute();
        }

    }
    private  class AT extends AsyncTask<Integer, Integer, Long> {
        private String term;
        private String formattedDate;

        protected void onPreExecute() {
            Date c = new Date(System.currentTimeMillis() - 7L * 24 * 3600 * 1000);
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            formattedDate = df.format(c);
            EditText et = (EditText) containerActivity.findViewById(R.id.edit);
            term = et.getText().toString();
        }



        protected Long doInBackground(Integer... p) {
            try {
                String json = "";
                String line;
                URL url = new URL("https://newsapi.org/v2/everything?sortBy=publishedAt&q="+term+"&from="+formattedDate+"&apiKey=eca746b521f84445ae8e3f7ac9a55047");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while ((line = in.readLine()) != null) {
                    json += line;
                }
                in.close();
                JSONObject jsonObject = new JSONObject(json);
                array = jsonObject.getJSONArray("articles");



            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }



        protected void onProgressUpdate(Integer... progress) {
            /* Run on UI thread, in response to a publishProgress call */
        }

        protected void onPostExecute(Long result) {
            List<HashMap<String, String>> aList =
                    new ArrayList<HashMap<String, String>>();
            for(int i = 0; i<array.length(); i++){
                try {
                    HashMap<String, String> hm = new HashMap<String, String>();
                    JSONObject json = array.getJSONObject(i);
                    String author = "("+json.getString("author")+")";
                    json = json.getJSONObject("source");
                    String site = json.getString("name");
                    hm.put("t1",site);
                    hm.put("t2",author);
                    aList.add(hm);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            String[] from = {"t1", "t2"};
            int[] to = {R.id.site, R.id.author};
            SimpleAdapter simpleAdapter =
                    new SimpleAdapter(containerActivity, aList,
                            R.layout.list, from, to);
            ListView lv = (ListView) containerActivity.findViewById(R.id.listView);
            lv.setAdapter(simpleAdapter);

        }
    }



}
